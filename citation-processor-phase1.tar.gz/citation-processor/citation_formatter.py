"""
Multi-Format Citation Formatter
Handles books, articles, websites, chapters in Chicago, MLA, APA, Bluebook
"""

from citation_parser import SourceType

class CitationFormatter:
    """Formats citations in various styles based on source type"""
    
    def format_citation(self, data: dict, style: str) -> str:
        """Main formatting function - routes to appropriate formatter"""
        source_type = data.get('source_type', SourceType.UNKNOWN)
        
        if style.lower() == 'chicago':
            return self._format_chicago(data, source_type)
        elif style.lower() == 'mla':
            return self._format_mla(data, source_type)
        elif style.lower() == 'apa':
            return self._format_apa(data, source_type)
        elif style.lower() == 'bluebook':
            return self._format_bluebook(data, source_type)
        else:
            return self._format_chicago(data, source_type)  # Default
    
    # ==================== CHICAGO STYLE ====================
    
    def _format_chicago(self, data: dict, source_type: str) -> str:
        """Format in Chicago Manual of Style"""
        if source_type == SourceType.BOOK:
            return self._chicago_book(data)
        elif source_type == SourceType.JOURNAL_ARTICLE:
            return self._chicago_journal(data)
        elif source_type == SourceType.NEWSPAPER_ARTICLE:
            return self._chicago_newspaper(data)
        elif source_type == SourceType.WEBSITE:
            return self._chicago_website(data)
        elif source_type == SourceType.BOOK_CHAPTER:
            return self._chicago_chapter(data)
        else:
            return data.get('original_text', '')
    
    def _chicago_book(self, data: dict) -> str:
        """Chicago: Author, Title (Place: Publisher, Year), page."""
        author = data.get('author', '')
        title = data.get('title', '')
        place = data.get('place', '')
        publisher = data.get('publisher', '')
        year = data.get('year', '')
        page = data.get('page', '')
        
        citation = f"{author}, <em>{title}</em>" if author and title else data.get('original_text', '')
        
        if place or publisher or year:
            citation += ' ('
            if place:
                citation += place
                if publisher or year:
                    citation += ': '
            if publisher:
                citation += publisher
                if year:
                    citation += ', '
            if year:
                citation += str(year)
            citation += ')'
        
        if page:
            citation += f', {page}'
        citation += '.'
        
        return citation
    
    def _chicago_journal(self, data: dict) -> str:
        """Chicago: Author, "Article Title," Journal Name vol, no. issue (Year): pages."""
        author = data.get('author', '')
        title = data.get('title', '')
        journal = data.get('journal', '')
        volume = data.get('volume', '')
        issue = data.get('issue', '')
        year = data.get('year', '')
        pages = data.get('pages', '')
        
        citation = author
        if title:
            citation += f', "{title}"'
        if journal:
            citation += f', <em>{journal}</em>'
        if volume:
            citation += f' {volume}'
            if issue:
                citation += f', no. {issue}'
        if year:
            citation += f' ({year})'
        if pages:
            citation += f': {pages}'
        citation += '.'
        
        return citation
    
    def _chicago_newspaper(self, data: dict) -> str:
        """Chicago: Author, "Article Title," Newspaper Name, Date."""
        author = data.get('author', '')
        title = data.get('title', '')
        publication = data.get('publication', '')
        date = data.get('date', '')
        
        citation = author
        if title:
            citation += f', "{title}"'
        if publication:
            citation += f', <em>{publication}</em>'
        if date:
            citation += f', {date}'
        citation += '.'
        
        return citation
    
    def _chicago_website(self, data: dict) -> str:
        """Chicago: Author, "Page Title," Website Name, access date, URL."""
        author = data.get('author', '')
        title = data.get('title', '')
        website_name = data.get('website_name', '')
        access_date = data.get('access_date', '')
        url = data.get('url', '')
        
        citation = author if author else ''
        if title:
            if citation:
                citation += ', '
            citation += f'"{title}"'
        if website_name:
            citation += f', {website_name}'
        if access_date:
            citation += f', accessed {access_date}'
        if url:
            citation += f', {url}'
        citation += '.'
        
        return citation
    
    def _chicago_chapter(self, data: dict) -> str:
        """Chicago: Author, "Chapter Title," in Book Title, ed. Editor (Place: Publisher, Year), pages."""
        author = data.get('author', '')
        title = data.get('title', '')
        book_title = data.get('book_title', '')
        editor = data.get('editor', '')
        place = data.get('place', '')
        publisher = data.get('publisher', '')
        year = data.get('year', '')
        pages = data.get('pages', data.get('page', ''))
        
        citation = author
        if title:
            citation += f', "{title}"'
        if book_title:
            citation += f', in <em>{book_title}</em>'
        if editor:
            citation += f', ed. {editor}'
        
        if place or publisher or year:
            citation += ' ('
            if place:
                citation += place
                if publisher or year:
                    citation += ': '
            if publisher:
                citation += publisher
                if year:
                    citation += ', '
            if year:
                citation += str(year)
            citation += ')'
        
        if pages:
            citation += f', {pages}'
        citation += '.'
        
        return citation
    
    # ==================== MLA STYLE ====================
    
    def _format_mla(self, data: dict, source_type: str) -> str:
        """Format in MLA style"""
        if source_type == SourceType.BOOK:
            return self._mla_book(data)
        elif source_type == SourceType.JOURNAL_ARTICLE:
            return self._mla_journal(data)
        elif source_type == SourceType.NEWSPAPER_ARTICLE:
            return self._mla_newspaper(data)
        elif source_type == SourceType.WEBSITE:
            return self._mla_website(data)
        elif source_type == SourceType.BOOK_CHAPTER:
            return self._mla_chapter(data)
        else:
            return data.get('original_text', '')
    
    def _mla_book(self, data: dict) -> str:
        """MLA: Last, First. Title. Publisher, Year."""
        author = data.get('author', '')
        title = data.get('title', '')
        publisher = data.get('publisher', '')
        year = data.get('year', '')
        
        # Invert author name
        if author:
            parts = author.split()
            if len(parts) >= 2:
                author = f"{parts[-1]}, {' '.join(parts[:-1])}"
        
        citation = f"{author}. " if author else ''
        citation += f"<em>{title}</em>. " if title else ''
        citation += f"{publisher}, " if publisher else ''
        citation += f"{year}." if year else '.'
        
        return citation
    
    def _mla_journal(self, data: dict) -> str:
        """MLA: Last, First. "Article Title." Journal, vol. X, no. Y, Year, pp. Z-ZZ."""
        author = data.get('author', '')
        title = data.get('title', '')
        journal = data.get('journal', '')
        volume = data.get('volume', '')
        issue = data.get('issue', '')
        year = data.get('year', '')
        pages = data.get('pages', '')
        
        # Invert author
        if author:
            parts = author.split()
            if len(parts) >= 2:
                author = f"{parts[-1]}, {' '.join(parts[:-1])}"
        
        citation = f"{author}. " if author else ''
        citation += f'"{title}." ' if title else ''
        citation += f"<em>{journal}</em>, " if journal else ''
        citation += f"vol. {volume}, " if volume else ''
        citation += f"no. {issue}, " if issue else ''
        citation += f"{year}, " if year else ''
        citation += f"pp. {pages}." if pages else '.'
        
        return citation
    
    def _mla_newspaper(self, data: dict) -> str:
        """MLA: Last, First. "Article Title." Newspaper, Date, page."""
        author = data.get('author', '')
        title = data.get('title', '')
        publication = data.get('publication', '')
        date = data.get('date', '')
        
        if author:
            parts = author.split()
            if len(parts) >= 2:
                author = f"{parts[-1]}, {' '.join(parts[:-1])}"
        
        citation = f"{author}. " if author else ''
        citation += f'"{title}." ' if title else ''
        citation += f"<em>{publication}</em>, " if publication else ''
        citation += f"{date}." if date else '.'
        
        return citation
    
    def _mla_website(self, data: dict) -> str:
        """MLA: Last, First. "Page Title." Website Name, Date, URL."""
        author = data.get('author', '')
        title = data.get('title', '')
        website_name = data.get('website_name', '')
        year = data.get('year', '')
        url = data.get('url', '')
        
        if author:
            parts = author.split()
            if len(parts) >= 2:
                author = f"{parts[-1]}, {' '.join(parts[:-1])}"
        
        citation = f"{author}. " if author else ''
        citation += f'"{title}." ' if title else ''
        citation += f"{website_name}, " if website_name else ''
        citation += f"{year}, " if year else ''
        citation += f"{url}." if url else '.'
        
        return citation
    
    def _mla_chapter(self, data: dict) -> str:
        """MLA: Last, First. "Chapter Title." Book Title, edited by Editor, Publisher, Year, pp. X-Y."""
        author = data.get('author', '')
        title = data.get('title', '')
        book_title = data.get('book_title', '')
        editor = data.get('editor', '')
        publisher = data.get('publisher', '')
        year = data.get('year', '')
        pages = data.get('pages', data.get('page', ''))
        
        if author:
            parts = author.split()
            if len(parts) >= 2:
                author = f"{parts[-1]}, {' '.join(parts[:-1])}"
        
        citation = f"{author}. " if author else ''
        citation += f'"{title}." ' if title else ''
        citation += f"<em>{book_title}</em>, " if book_title else ''
        citation += f"edited by {editor}, " if editor else ''
        citation += f"{publisher}, " if publisher else ''
        citation += f"{year}, " if year else ''
        citation += f"pp. {pages}." if pages else '.'
        
        return citation
    
    # ==================== APA STYLE ====================
    
    def _format_apa(self, data: dict, source_type: str) -> str:
        """Format in APA style"""
        if source_type == SourceType.BOOK:
            return self._apa_book(data)
        elif source_type == SourceType.JOURNAL_ARTICLE:
            return self._apa_journal(data)
        elif source_type == SourceType.NEWSPAPER_ARTICLE:
            return self._apa_newspaper(data)
        elif source_type == SourceType.WEBSITE:
            return self._apa_website(data)
        elif source_type == SourceType.BOOK_CHAPTER:
            return self._apa_chapter(data)
        else:
            return data.get('original_text', '')
    
    def _apa_book(self, data: dict) -> str:
        """APA: Author, A. A. (Year). Title. Publisher."""
        author = data.get('author', '')
        title = data.get('title', '')
        publisher = data.get('publisher', '')
        year = data.get('year', '')
        
        # APA uses initials
        if author:
            parts = author.split()
            if len(parts) >= 2:
                initials = '. '.join([p[0] for p in parts[:-1]]) + '.'
                author = f"{parts[-1]}, {initials}"
        
        citation = f"{author} " if author else ''
        citation += f"({year}). " if year else ''
        citation += f"<em>{title}</em>. " if title else ''
        citation += f"{publisher}." if publisher else '.'
        
        return citation
    
    def _apa_journal(self, data: dict) -> str:
        """APA: Author, A. A. (Year). Article title. Journal Name, vol(issue), pages."""
        author = data.get('author', '')
        title = data.get('title', '')
        journal = data.get('journal', '')
        volume = data.get('volume', '')
        issue = data.get('issue', '')
        year = data.get('year', '')
        pages = data.get('pages', '')
        
        if author:
            parts = author.split()
            if len(parts) >= 2:
                initials = '. '.join([p[0] for p in parts[:-1]]) + '.'
                author = f"{parts[-1]}, {initials}"
        
        citation = f"{author} " if author else ''
        citation += f"({year}). " if year else ''
        citation += f"{title}. " if title else ''
        citation += f"<em>{journal}</em>, " if journal else ''
        
        if volume:
            citation += f"<em>{volume}</em>"
            if issue:
                citation += f"({issue})"
            citation += ', '
        
        citation += f"{pages}." if pages else '.'
        
        return citation
    
    def _apa_newspaper(self, data: dict) -> str:
        """APA: Author, A. A. (Date). Article title. Newspaper Name."""
        author = data.get('author', '')
        title = data.get('title', '')
        publication = data.get('publication', '')
        date = data.get('date', '')
        
        if author:
            parts = author.split()
            if len(parts) >= 2:
                initials = '. '.join([p[0] for p in parts[:-1]]) + '.'
                author = f"{parts[-1]}, {initials}"
        
        citation = f"{author} " if author else ''
        citation += f"({date}). " if date else ''
        citation += f"{title}. " if title else ''
        citation += f"<em>{publication}</em>." if publication else '.'
        
        return citation
    
    def _apa_website(self, data: dict) -> str:
        """APA: Author, A. A. (Year). Page title. Site Name. URL"""
        author = data.get('author', '')
        title = data.get('title', '')
        website_name = data.get('website_name', '')
        year = data.get('year', '')
        url = data.get('url', '')
        
        if author:
            parts = author.split()
            if len(parts) >= 2:
                initials = '. '.join([p[0] for p in parts[:-1]]) + '.'
                author = f"{parts[-1]}, {initials}"
        
        citation = f"{author} " if author else ''
        citation += f"({year}). " if year else ''
        citation += f"{title}. " if title else ''
        citation += f"{website_name}. " if website_name else ''
        citation += f"{url}" if url else ''
        
        return citation
    
    def _apa_chapter(self, data: dict) -> str:
        """APA: Author, A. A. (Year). Chapter title. In E. Editor (Ed.), Book title (pp. x-y). Publisher."""
        author = data.get('author', '')
        title = data.get('title', '')
        book_title = data.get('book_title', '')
        editor = data.get('editor', '')
        publisher = data.get('publisher', '')
        year = data.get('year', '')
        pages = data.get('pages', data.get('page', ''))
        
        if author:
            parts = author.split()
            if len(parts) >= 2:
                initials = '. '.join([p[0] for p in parts[:-1]]) + '.'
                author = f"{parts[-1]}, {initials}"
        
        citation = f"{author} " if author else ''
        citation += f"({year}). " if year else ''
        citation += f"{title}. " if title else ''
        
        if book_title:
            citation += f"In "
            if editor:
                citation += f"{editor} (Ed.), "
            citation += f"<em>{book_title}</em> "
            if pages:
                citation += f"(pp. {pages})"
            citation += ". "
        
        citation += f"{publisher}." if publisher else '.'
        
        return citation
    
    # ==================== BLUEBOOK STYLE ====================
    
    def _format_bluebook(self, data: dict, source_type: str) -> str:
        """Format in Bluebook legal citation style"""
        # Simplified Bluebook for now - legal citations are complex
        author = data.get('author', '')
        title = data.get('title', '')
        year = data.get('year', '')
        
        citation = f"{author}, " if author else ''
        citation += title.upper() if title else ''
        
        if year:
            citation += f" ({year})"
        
        citation += '.'
        
        return citation


# Testing
if __name__ == "__main__":
    from citation_parser import CitationParser
    
    parser = CitationParser()
    formatter = CitationFormatter()
    
    test_citation = 'John Smith, "The Future of AI," Journal of Computer Science, vol. 45, no. 2 (2023): 123-145.'
    
    parsed = parser.parse_citation(test_citation)
    print(f"Original: {test_citation}")
    print(f"Type: {parsed['source_type']}")
    print(f"\nChicago: {formatter.format_citation(parsed, 'chicago')}")
    print(f"MLA: {formatter.format_citation(parsed, 'mla')}")
    print(f"APA: {formatter.format_citation(parsed, 'apa')}")
